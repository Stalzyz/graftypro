"use client";
import React, { useEffect, useState } from 'react';
import { Check, ArrowRight, Loader2, Zap, Star, MessageSquare } from 'lucide-react';
import Link from 'next/link';

interface Plan {
    id: string;
    name: string;
    monthly_price: number;
    yearly_price: number;
    original_monthly_price: number;
    original_yearly_price: number;
    price: number;
    credits: number;
    features: string[];
    features_list: string[];
    is_featured: boolean;
    badge_text: string;
    cta_label: string;
    accent_color: string;
    sort_order: number;
    flow_builder_access: boolean;
    drip_campaign_access: boolean;
    commerce_access: boolean;
    edu_engine_access: boolean;
    api_access: boolean;
}

interface DynamicPricingProps {
    title?: string;
    subtitle?: string;
    manualPlans?: any[];
    autoSync?: boolean;
}

export default function DynamicPricing({
    title = "Premium Infrastructure <br/> <span class='text-emerald-500'>Transparent Operational Economics.</span>",
    subtitle = "Choose a plan designed for high-authority business operators.",
    manualPlans,
    autoSync = true
}: DynamicPricingProps) {
    const [plans, setPlans] = useState<Plan[]>([]);
    const [loading, setLoading] = useState(true);
    const [billing, setBilling] = useState<'monthly' | 'yearly'>('monthly');
    const [isLoggedIn, setIsLoggedIn] = useState(false);

    useEffect(() => {
        // Server-verified auth check
        fetch("/api/auth/trial-status")
            .then(res => setIsLoggedIn(res.ok))
            .catch(() => setIsLoggedIn(false));

        if (!autoSync && manualPlans) {
            setPlans(manualPlans);
            setLoading(false);
            return;
        }
        const fetchPlans = async () => {
            try {
                const res = await fetch('/api/billing/plans');
                const json = await res.json();
                if (json.data) {
                    setPlans(json.data); // already sorted by API
                }
            } catch (err) {
                console.error("Failed to fetch plans", err);
            } finally {
                setLoading(false);
            }
        };
        fetchPlans();
    }, [autoSync, manualPlans]);

    if (loading) {
        return (
            <section id="pricing" className="section-white flex items-center justify-center min-h-[400px]">
                <Loader2 className="animate-spin text-emerald-500" size={40} />
            </section>
        );
    }

    return (
        <section id="pricing" className="section-white py-24">
            <div className="max-w-7xl mx-auto px-6">
                {/* Header */}
                <div className="text-center mb-16 animate-up">
                    <h2 className="text-5xl font-black tracking-tighter mb-6 italic" dangerouslySetInnerHTML={{ __html: title }} />
                    <p className="text-slate-500 text-lg mb-10 max-w-2xl mx-auto">{subtitle}</p>

                    {/* Billing Toggle — always on top */}
                    <div className="inline-flex items-center gap-1 bg-slate-100 p-1.5 rounded-2xl shadow-inner">
                        <button
                            onClick={() => setBilling('monthly')}
                            className={`px-8 py-3 rounded-xl text-sm font-black uppercase tracking-widest transition-all ${billing === 'monthly' ? 'bg-white text-slate-900 shadow-xl' : 'text-slate-500 hover:text-slate-700'}`}
                        >
                            Per Month
                        </button>
                        <button
                            onClick={() => setBilling('yearly')}
                            className={`px-8 py-3 rounded-xl text-sm font-black uppercase tracking-widest transition-all flex items-center gap-3 ${billing === 'yearly' ? 'bg-white text-slate-900 shadow-xl' : 'text-slate-500 hover:text-slate-700'}`}
                        >
                            Per Year
                            <span className="bg-emerald-100 text-emerald-700 text-[10px] font-black px-3 py-1 rounded-full border border-emerald-200 uppercase tracking-[0.1em]">
                                Save 20%
                            </span>
                        </button>
                    </div>
                </div>

                {/* All Plan Cards in unified grid */}
                <div className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-${Math.min(plans.length, 4)} gap-8`}>
                    {plans.map((plan) => {
                        const price = billing === 'yearly'
                            ? Math.round((plan.yearly_price || plan.monthly_price * 10) / 12)
                            : (plan.monthly_price || 0);
                        const originalPrice = billing === 'yearly'
                            ? Math.round((plan.original_yearly_price || plan.original_monthly_price * 12) / 12)
                            : (plan.original_monthly_price || price);
                        const yearlyTotal = plan.yearly_price || plan.monthly_price * 12;
                        const originalYearlyTotal = plan.original_yearly_price || plan.original_monthly_price * 12;
                        const savings = Math.max(0, originalPrice - price);
                        const accentColor = plan.accent_color || "#27954D";
                        const isFeatured = plan.is_featured;

                        return (
                            <PriceCard
                                key={plan.id}
                                plan={plan}
                                price={price}
                                originalPrice={originalPrice}
                                savings={savings}
                                yearly={billing === 'yearly'}
                                yearlyTotal={yearlyTotal}
                                originalYearlyTotal={originalYearlyTotal}
                                accentColor={accentColor}
                                isFeatured={isFeatured}
                                isLoggedIn={isLoggedIn}
                            />
                        );
                    })}
                </div>

                <div className="mt-16 text-center">
                    <p className="text-slate-400 text-sm font-medium">Looking for customized white-label solutions? <Link href="/contact" className="text-emerald-600 font-bold hover:underline">Speak with Architects</Link></p>
                </div>
            </div>
        </section>
    );
}

function PriceCard({
    plan, price, originalPrice, savings, yearly, yearlyTotal, originalYearlyTotal, accentColor, isFeatured, isLoggedIn
}: {
    plan: Plan;
    price: number;
    originalPrice: number;
    savings: number;
    yearly: boolean;
    yearlyTotal: number;
    originalYearlyTotal: number;
    accentColor: string;
    isFeatured: boolean;
    isLoggedIn: boolean;
}) {
    const slug = plan.name.toLowerCase().replace(/\s+/g, '-');
    const ctaLabel = plan.cta_label || "Get Started";
    const badgeText = plan.badge_text || "";
    const features: string[] = plan.features || plan.features_list || [];

    return (
        <div
            className={`relative flex flex-col rounded-[2.5rem] border-2 transition-all duration-500 hover:shadow-2xl ${isFeatured
                ? 'border-[var(--accent)] shadow-xl shadow-emerald-500/10 lg:scale-[1.03] z-10'
                : 'border-slate-100 hover:border-slate-200'
                }`}
            style={{ '--accent': accentColor } as React.CSSProperties}
        >
            {/* Badge */}
            {badgeText && (
                <div
                    className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 text-white text-[10px] font-black uppercase tracking-[2px] px-6 py-2 rounded-full shadow-xl whitespace-nowrap z-20"
                    style={{ backgroundColor: accentColor }}
                >
                    {badgeText}
                </div>
            )}

            {/* Card Header */}
            <div className="p-8 lg:p-10 bg-white flex-1 flex flex-col">
                {/* Plan Name */}
                <div className="mb-8">
                    <div className="flex items-center gap-2 mb-3">
                        <div className="w-2 h-2 rounded-full" style={{ backgroundColor: accentColor }} />
                        <span className="text-[10px] font-black uppercase tracking-[4px] text-slate-400">{plan.name}</span>
                    </div>

                    {/* Price Display */}
                    <div className="space-y-1 mb-4">
                        {originalPrice > price && (
                            <div className="flex items-center gap-2">
                                <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">MSRP:</span>
                                <span className="text-sm font-bold line-through text-slate-400">₹{originalPrice.toLocaleString()}/mo</span>
                            </div>
                        )}

                        <div className="flex items-baseline gap-1">
                            <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 mr-1">Selling Price</span>
                            <span className="text-4xl font-black tracking-tighter leading-none text-slate-900">
                                ₹{price.toLocaleString()}
                            </span>
                            <span className="font-black uppercase text-[10px] tracking-widest text-slate-400">/mo</span>
                        </div>

                        {savings > 0 && (
                            <span
                                className="inline-block text-[9px] font-black px-2 py-0.5 rounded uppercase tracking-widest mt-1 text-white"
                                style={{ backgroundColor: accentColor }}
                            >
                                You Save ₹{savings.toLocaleString()}/mo
                            </span>
                        )}
                    </div>

                    {yearly && (
                        <div className="space-y-0.5">
                            {originalYearlyTotal > yearlyTotal && (
                                <p className="text-[10px] text-slate-400 font-bold line-through">
                                    ₹{originalYearlyTotal.toLocaleString()}/yr
                                </p>
                            )}
                            <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">
                                Billed ₹{yearlyTotal.toLocaleString()}/year
                            </p>
                        </div>
                    )}
                </div>



                {/* Features */}
                <ul className="space-y-3 mb-8 flex-grow">
                    {/* Credits as first feature */}
                    {(plan.credits || 0) > 0 && (
                        <li className="flex gap-3 items-center">
                            <div
                                className="flex-shrink-0 w-5 h-5 rounded-full flex items-center justify-center text-white"
                                style={{ backgroundColor: accentColor }}
                            >
                                <Check size={11} strokeWidth={3} />
                            </div>
                            <span className="font-black text-[13px] leading-relaxed" style={{ color: accentColor }}>
                                {(plan.credits || 0).toLocaleString()} Free Credits / Month
                            </span>
                        </li>
                    )}
                    {features.map((f, i) => (
                        <li key={i} className="flex gap-3 items-start">
                            <div
                                className="mt-0.5 flex-shrink-0 w-5 h-5 rounded-full flex items-center justify-center text-white"
                                style={{ backgroundColor: accentColor }}
                            >
                                <Check size={11} strokeWidth={3} />
                            </div>
                            <span className="font-semibold text-[13px] leading-relaxed text-slate-600">{f}</span>
                        </li>
                    ))}
                </ul>

                {/* CTA */}
                <div className="mt-auto">
                    <Link
                        href={isLoggedIn ? `/dashboard/settings/billing?plan=${slug}` : `/register?plan=${slug}&billing=${yearly ? 'yearly' : 'monthly'}`}
                        className="w-full group py-5 rounded-2xl text-[11px] font-black uppercase tracking-[3px] flex items-center justify-center gap-3 transition-all active:scale-[0.98] shadow-lg text-white hover:opacity-90"
                        style={{ backgroundColor: accentColor }}
                    >
                        <Zap size={14} className="text-white/80" />
                        {isLoggedIn ? "Upgrade Plan" : ctaLabel}
                        <ArrowRight size={14} className="group-hover:translate-x-1.5 transition-transform" />
                    </Link>
                    <p className="text-center text-[9px] font-black uppercase tracking-[2px] mt-4 text-slate-400">
                        {plan.monthly_price === 0 ? "Free forever, no credit card needed" : "No credit card required for trial"}
                    </p>
                </div>
            </div>
        </div>
    );
}
