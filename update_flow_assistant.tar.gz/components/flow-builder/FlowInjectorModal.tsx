"use client";

import { useState } from "react";
import { 
    X, 
    Zap, 
    Code, 
    Rocket, 
    ArrowRight, 
    ShieldCheck, 
    Users,
    MessageSquare,
    Loader2,
    Sparkles
} from "lucide-react";

interface FlowInjectorModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSuccess: () => void;
}

export default function FlowInjectorModal({ isOpen, onClose, onSuccess }: FlowInjectorModalProps) {
    const [jsonInput, setJsonInput] = useState("");
    const [aiPrompt, setAiPrompt] = useState("");
    const [loading, setLoading] = useState(false);
    const [generating, setGenerating] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleAIGenerate = async () => {
        if (!aiPrompt.trim()) return;
        setGenerating(true);
        setError(null);
        try {
            const res = await fetch("/api/flows/generate/ai", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ prompt: aiPrompt })
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || "AI Generation failed");
            
            setJsonInput(JSON.stringify(data.script, null, 4));
        } catch (err: any) {
            setError(err.message);
        } finally {
            setGenerating(false);
        }
    };

    const templates = [
        {
            id: 'VENDOR_ONBOARDING',
            name: 'Vendor Onboarding',
            description: 'Automated signup & CRM lead capture for new vendors.',
            icon: <ShieldCheck className="text-blue-500" />,
            script: {
                name: "Vendor Onboarding (Quick)",
                trigger_keyword: "start",
                steps: [
                    { id: "welcome", text: "Welcome! Are you ready to start your vendor onboarding?", options: [{ label: "Yes", next: "info" }, { label: "Support", next: "help" }] },
                    { id: "info", text: "Great! What is your business name?" },
                    { id: "help", text: "Notified admin! Someone will call you." }
                ]
            }
        },
        {
            id: 'AFFILIATE_PARTNER',
            name: 'Affiliate Portal',
            description: 'Self-service dashboard for affiliate partners.',
            icon: <Users className="text-purple-500" />,
            script: {
                name: "Affiliate Portal (Quick)",
                trigger_keyword: "partner",
                steps: [
                    { id: "menu", text: "Partner Menu: \n1. Earnings \n2. Links", options: [{ label: "Earnings", next: "earn" }, { label: "Link", next: "link" }] },
                    { id: "earn", text: "Your pending balance: ₹4,500" },
                    { id: "link", text: "Your link: https://grafty.pro/ref/123" }
                ]
            }
        }
    ];

    const handleInject = async (script?: any) => {
        setLoading(true);
        setError(null);
        
        try {
            const dataToInject = script || JSON.parse(jsonInput);
            
            const res = await fetch("/api/flows/generate", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(dataToInject)
            });

            const result = await res.json();

            if (!res.ok) {
                throw new Error(result.error || "Failed to inject flow");
            }

            onSuccess();
            onClose();
        } catch (err: any) {
            setError(err.message || "Invalid JSON structure");
        } finally {
            setLoading(false);
        }
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
            <div className="bg-white rounded-[2rem] w-full max-w-4xl max-h-[90vh] overflow-hidden shadow-2xl border border-gray-100 flex flex-col md:flex-row">
                
                {/* Left Sidebar: Templates */}
                <div className="w-full md:w-80 bg-gray-50/50 p-8 border-r border-gray-100">
                    <div className="flex items-center gap-2 mb-8">
                        <div className="w-8 h-8 bg-black rounded-lg flex items-center justify-center text-white">
                            <Rocket size={18} />
                        </div>
                        <h2 className="font-bold text-xl tracking-tight">AI Injectors</h2>
                    </div>

                    <p className="text-gray-500 text-xs font-bold uppercase tracking-widest mb-4">BSP Templates</p>
                    
                    <div className="space-y-3">
                        {templates.map((tpl) => (
                            <button
                                key={tpl.id}
                                onClick={() => handleInject(tpl.script)}
                                disabled={loading}
                                className="w-full text-left p-4 rounded-2xl bg-white border border-gray-100 hover:border-black/10 hover:shadow-md transition-all group"
                            >
                                <div className="flex items-center justify-between mb-2">
                                    <div className="p-2 bg-gray-50 rounded-lg group-hover:bg-white transition-colors">
                                        {tpl.icon}
                                    </div>
                                    <ArrowRight size={14} className="text-gray-300 group-hover:text-black transition-colors" />
                                </div>
                                <h3 className="font-bold text-sm text-gray-800">{tpl.name}</h3>
                                <p className="text-[11px] text-gray-500 mt-1 leading-relaxed">{tpl.description}</p>
                            </button>
                        ))}
                    </div>

                    <div className="mt-8 p-4 bg-black text-white rounded-2xl">
                        <div className="flex items-center gap-2 mb-2 text-yellow-400">
                            <Zap size={14} fill="currentColor" />
                            <span className="text-[10px] font-bold uppercase tracking-wider">Pro Tip</span>
                        </div>
                        <p className="text-[11px] opacity-70 leading-relaxed">Past any simplified "Dialogue Script" in the JSON editor to instantly build complex flows.</p>
                    </div>
                </div>

                {/* Right Area: JSON Editor */}
                <div className="flex-1 flex flex-col p-8 relative">
                    <button 
                        onClick={onClose}
                        className="absolute right-6 top-6 p-2 hover:bg-gray-100 rounded-full transition-colors text-gray-400"
                    >
                        <X size={20} />
                    </button>

                    <div className="mb-6">
                        <h2 className="text-2xl font-bold flex items-center gap-2">
                            <Sparkles size={24} className="text-purple-600 animate-pulse" />
                            AI Flow Assistant
                        </h2>
                        <p className="text-gray-500 text-sm mt-1">Describe your flow in plain English, and I'll write the code for you.</p>
                    </div>

                    {/* AI Prompt Input */}
                    <div className="flex gap-2 mb-6 p-2 bg-gray-50 rounded-2xl border border-gray-100 focus-within:border-purple-200 focus-within:ring-2 focus-within:ring-purple-50 transition-all">
                        <input 
                            type="text" 
                            className="flex-1 bg-transparent border-none outline-none px-4 text-sm font-medium"
                            placeholder="e.g., 'A pizza shop flow that asks for size and flavor, then collects payment'"
                            value={aiPrompt}
                            onChange={(e) => setAiPrompt(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && handleAIGenerate()}
                        />
                        <button 
                            onClick={handleAIGenerate}
                            disabled={generating || !aiPrompt.trim()}
                            className="bg-black text-white px-6 py-2 rounded-xl text-xs font-bold hover:opacity-80 disabled:opacity-30 transition-all flex items-center gap-2"
                        >
                            {generating ? (
                                <>
                                    <Loader2 className="animate-spin" size={12} />
                                    Brainstorming...
                                </>
                            ) : (
                                <>
                                    <Zap size={12} fill="currentColor" />
                                    Generate
                                </>
                            )}
                        </button>
                    </div>

                    <div className="flex-1 relative mb-6">
                        <div className="absolute top-4 left-6 flex items-center gap-2 z-10">
                            <Code size={12} className="text-gray-400" />
                            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">JSON SCRIPT EDITOR</span>
                        </div>
                        <textarea
                            className="w-full h-full min-h-[300px] pt-12 p-6 font-mono text-xs bg-gray-900 text-green-400 rounded-3xl outline-none focus:ring-2 ring-[#27954D]/20 border-none shadow-inner resize-none"
                            placeholder='{
    "name": "My AI Flow",
    "steps": [
        { "id": "hello", "text": "Welcome!" }
    ]
}'
                            value={jsonInput}
                            onChange={(e) => setJsonInput(e.target.value)}
                        />
                    </div>

                    {error && (
                        <div className="mb-6 p-4 bg-red-50 text-red-600 rounded-2xl text-xs font-medium border border-red-100">
                            Error: {error}
                        </div>
                    )}

                    <div className="flex items-center justify-between gap-4">
                        <div className="flex items-center gap-2 text-gray-400">
                            <MessageSquare size={16} />
                            <span className="text-xs">Supports: Text, Buttons, Media, CRM</span>
                        </div>
                        <button
                            onClick={() => handleInject()}
                            disabled={loading || !jsonInput.trim()}
                            className="btn-primary min-w-[200px] py-4 h-auto rounded-2xl shadow-lg shadow-[#27954D]/20 disabled:opacity-50"
                        >
                            {loading ? (
                                <>
                                    <Loader2 className="animate-spin mr-2" size={18} />
                                    Injecting...
                                </>
                            ) : (
                                <>
                                    <Rocket className="mr-2" size={18} />
                                    Inject Flow Code
                                </>
                            )}
                        </button>
                    </div>
                </div>

            </div>
        </div>
    );
}
