
// This file defines the blueprints for generating flows based on Goals.

export interface FlowNode {
    id: string;
    type: string;
    position: { x: number; y: number };
    data: any;
}

export interface FlowEdge {
    id: string;
    source: string;
    target: string;
    label?: string;
    type?: string;
}

export const GOAL_TEMPLATES = {
    BOOK_APPOINTMENT: {
        name: "Standard Appointment Booking",
        generate: (workspaceId: string, config: any) => {
            return {
                nodes: [
                    {
                        id: '1',
                        type: 'message',
                        position: { x: 250, y: 0 },
                        data: { text: `Hello! 👋 Welcome to our business. Would you like to book an appointment with us?` }
                    },
                    {
                        id: '2',
                        type: 'option_buttons',
                        position: { x: 250, y: 150 },
                        data: {
                            text: "Please select an option:",
                            options: ["Book Now", "View Services", "Talk to Human"]
                        }
                    },
                    {
                        id: '3',
                        type: 'message',
                        position: { x: 0, y: 300 },
                        data: { text: "Great! Please select a preferred date below." }
                    }
                ] as FlowNode[],
                edges: [
                    { id: 'e1-2', source: '1', target: '2' },
                    { id: 'e2-3', source: '2', target: '3', label: 'Book Now' }
                ] as FlowEdge[]
            }
        }
    },

    COLLECT_PAYMENT: {
        name: "Payment Collection Reminder",
        generate: (workspaceId: string, config: any) => {
            return {
                nodes: [
                    {
                        id: '1',
                        type: 'message',
                        position: { x: 250, y: 0 },
                        data: { text: `Hi, this is a gentle reminder that your payment of $${config.amount} is pending.` }
                    },
                    {
                        id: '2',
                        type: 'payment_cta',
                        position: { x: 250, y: 150 },
                        data: { amount: config.amount, link: config.link, buttonText: "Pay Now" }
                    }
                ],
                edges: [
                    { id: 'e1-2', source: '1', target: '2' }
                ]
            }
        }
    },

    SELL_PRODUCT: {
        name: "Sell Products (Commerce)",
        generate: (workspaceId: string, config: any) => {
            return {
                nodes: [
                    {
                        id: '1',
                        type: 'message',
                        position: { x: 250, y: 0 },
                        data: { text: "Check out our latest collection! 👇" }
                    },
                    {
                        id: '2',
                        type: 'product_list',
                        position: { x: 250, y: 150 },
                        data: {
                            header: "Featured Products",
                            items: [
                                { id: "p1", title: "Premium Watch", description: "$150", actionId: "buy_p1" },
                                { id: "p2", title: "Sunglasses", description: "$50", actionId: "buy_p2" }
                            ]
                        }
                    },
                    {
                        id: '3',
                        type: 'message',
                        position: { x: 250, y: 300 },
                        data: { text: "Excellent choice! Here is your secure payment link: https://pay.link/demo" }
                    }
                ],
                edges: [
                    { id: 'e1-2', source: '1', target: '2' },
                    { id: 'e2-3', source: '2', target: '3' }
                ]
            }
        }
    },

    VENDOR_ONBOARDING: {
        name: "Vendor Onboarding Flow",
        generate: (workspaceId: string, config: any) => {
            return {
                nodes: [
                    {
                        id: 'start',
                        type: 'start',
                        position: { x: 400, y: 0 },
                        data: { label: "Start Onboarding" }
                    },
                    {
                        id: 'welcome',
                        type: 'message',
                        position: { x: 400, y: 100 },
                        data: { 
                            text: "Welcome to our BSP Platform! 🚀\n\nI'm here to help you get your WhatsApp Business API set up and ready to go.",
                            buttons: [
                                { type: 'reply', reply: { id: 'btn_features', title: 'Explore Features 🌟' } },
                                { type: 'reply', reply: { id: 'btn_onboard', title: 'Start Onboarding 📝' } },
                                { type: 'reply', reply: { id: 'btn_support', title: 'Talk to Support 🎧' } }
                            ]
                        }
                    },
                    {
                        id: 'features',
                        type: 'message',
                        position: { x: 100, y: 300 },
                        data: { 
                            text: "Our platform offers:\n\n✅ Visual Flow Builder\n✅ Broadcast Campaigns\n✅ CRM Integration\n✅ Automated Drip Sequences\n✅ Native Payments\n\nWould you like to start your 7-day free trial?",
                            buttons: [
                                { type: 'reply', reply: { id: 'btn_onboard', title: 'Yes, Start Trial! 🚀' } },
                                { type: 'reply', reply: { id: 'btn_back', title: 'Main Menu ⬅️' } }
                            ]
                        }
                    },
                    {
                        id: 'collect_name',
                        type: 'message',
                        position: { x: 400, y: 300 },
                        data: { text: "Great! Let's get started. What is your Business Name?" }
                    },
                    {
                        id: 'save_lead',
                        type: 'action',
                        position: { x: 400, y: 450 },
                        data: { 
                            actionType: 'save_to_crm',
                            label: "Sync to CRM"
                        }
                    },
                    {
                        id: 'onboarding_info',
                        type: 'message',
                        position: { x: 400, y: 550 },
                        data: { 
                            text: "Business Name Captured! ✅\n\nTo complete your setup, we need to verify your WABA (WhatsApp Business Account).\n\nPlease have your Business Manager ID ready.",
                            buttons: [
                                { type: 'reply', reply: { id: 'btn_docs', title: 'View Guide 📖' } },
                                { type: 'reply', reply: { id: 'btn_ready', title: 'I am Ready! ✅' } }
                            ]
                        }
                    },
                    {
                        id: 'support_node',
                        type: 'action',
                        position: { x: 700, y: 300 },
                        data: { 
                            actionType: 'send_email',
                            emailSubject: "Vendor Support Request",
                            emailAddress: "admin@grafty.pro",
                            label: "Notify Admin"
                        }
                    },
                    {
                        id: 'support_msg',
                        type: 'message',
                        position: { x: 700, y: 450 },
                        data: { text: "I've notified our support team. An agent will reach out to you on this number shortly! 🙏" }
                    }
                ],
                edges: [
                    { id: 'e-s-w', source: 'start', target: 'welcome' },
                    { id: 'e-w-f', source: 'welcome', target: 'features', label: 'Explore Features 🌟' },
                    { id: 'e-w-o', source: 'welcome', target: 'collect_name', label: 'Start Onboarding 📝' },
                    { id: 'e-w-s', source: 'welcome', target: 'support_node', label: 'Talk to Support 🎧' },
                    { id: 'e-f-o', source: 'features', target: 'collect_name', label: 'Yes, Start Trial! 🚀' },
                    { id: 'e-f-b', source: 'features', target: 'welcome', label: 'Main Menu ⬅️' },
                    { id: 'e-c-s', source: 'collect_name', target: 'save_lead' },
                    { id: 'e-s-i', source: 'save_lead', target: 'onboarding_info' },
                    { id: 'e-sn-sm', source: 'support_node', target: 'support_msg' }
                ]
            }
        }
    },

    AFFILIATE_PARTNER: {
        name: "Affiliate Partner Dashboard Flow",
        generate: (workspaceId: string, config: any) => {
            return {
                nodes: [
                    {
                        id: 'start',
                        type: 'start',
                        position: { x: 400, y: 0 },
                        data: { label: "Partner Access" }
                    },
                    {
                        id: 'welcome',
                        type: 'message',
                        position: { x: 400, y: 100 },
                        data: { 
                            text: "Hello Partner! 👋 Ready to scale your earnings today?\n\nSelect an option below to manage your affiliate account.",
                            buttons: [
                                { type: 'reply', reply: { id: 'btn_earnings', title: 'My Earnings 💰' } },
                                { type: 'reply', reply: { id: 'btn_link', title: 'Referral Link 🔗' } },
                                { type: 'reply', reply: { id: 'btn_upgrade', title: 'Scale to Platform 🚀' } }
                            ]
                        }
                    },
                    {
                        id: 'earnings_msg',
                        type: 'message',
                        position: { x: 100, y: 300 },
                        data: { 
                            text: "📊 *Your Performance Snapshot*\n\nTotal Referrals: 12\nPending Commission: ₹4,500\nTotal Withdrawn: ₹12,000\n\nWithdrawals are processed every Friday. ✅",
                            buttons: [
                                { type: 'reply', reply: { id: 'btn_back', title: 'Back to Menu ⬅️' } }
                            ]
                        }
                    },
                    {
                        id: 'link_msg',
                        type: 'message',
                        position: { x: 400, y: 300 },
                        data: { 
                            text: "🔗 *Your Unique Referral Link*\n\nhttps://grafty.pro/register?ref={{referral_code}}\n\nShare this link with potential vendors. You get 20% lifetime commission on every successful subscription! 💸"
                        }
                    },
                    {
                        id: 'upgrade_info',
                        type: 'message',
                        position: { x: 700, y: 300 },
                        data: { 
                            text: "🚀 *Scale to Platform Partner*\n\nGet your own white-labeled dashboard, custom domain, and the ability to set your own markup.\n\nRequirement: 10+ active vendors.\n\nWould you like to request an upgrade?",
                            buttons: [
                                { type: 'reply', reply: { id: 'btn_req_upgrade', title: 'Request Upgrade' } },
                                { type: 'reply', reply: { id: 'btn_back', title: 'Main Menu ⬅️' } }
                            ]
                        }
                    },
                    {
                        id: 'req_upgrade_node',
                        type: 'action',
                        position: { x: 700, y: 450 },
                        data: { 
                            actionType: 'webhook',
                            label: "Notify Admin"
                        }
                    },
                    {
                        id: 'upgrade_done',
                        type: 'message',
                        position: { x: 700, y: 550 },
                        data: { text: "Upgrade request sent! 🚀 Our team will review your account performance and get back to you within 24 hours." }
                    }
                ],
                edges: [
                    { id: 'e-s-w', source: 'start', target: 'welcome' },
                    { id: 'e-w-e', source: 'welcome', target: 'earnings_msg', label: 'My Earnings 💰' },
                    { id: 'e-w-l', source: 'welcome', target: 'link_msg', label: 'Referral Link 🔗' },
                    { id: 'e-w-u', source: 'welcome', target: 'upgrade_info', label: 'Scale to Platform 🚀' },
                    { id: 'e-e-b', source: 'earnings_msg', target: 'welcome', label: 'Back to Menu ⬅️' },
                    { id: 'e-u-b', source: 'upgrade_info', target: 'welcome', label: 'Main Menu ⬅️' },
                    { id: 'e-u-r', source: 'upgrade_info', target: 'req_upgrade_node', label: 'Request Upgrade' },
                    { id: 'e-r-d', source: 'req_upgrade_node', target: 'upgrade_done' }
                ]
            }
        }
    }
};
